***********
* README *
***********

In the project, several approaches have been implemented in order to decide whether or not the oblivious and semi-oblivious chase terminates under a set of linear or simple linear TGDs.
The project is divided as follows. In the corresponding directory, two projects written in Java language programming exist. 

SimpleLinearTGDS
--------------------------------------------------------
The first project called SimpleLinearTGDs contains all the material that is related to the algorithms consider simple Linear TGDs. 
This project contains the following four packages:
***************************************************************************
Package �Detect cycles�: This package contain all the classes that implement the Donald Johnson algorithm in order to find the cycles in a directed graph. 
The main method is contained in the class called �TestCycles�. 
In this class the user defines if the weak-acyclicity or rich-acyclicity is going to be checked.
Also, in this class the file of simple linear TGDs that is going to be read must be defined as well. 
***************************************************************************
Package �GRAPHS�: This package contains two classes called DependencyGraph and ExtendedDependencyGraph. 
These classes are responsible to compute the special edges and the normal edges of the graph that will be constructed. 
When the Rich-acyclicity is checked, the ExtendedDependencyGraph class is used in order to construct the graph. On the other hand, if the weak-acyclicity is checked the system uses the DependencyGraph class in order to construct the graph. 
This classes are called from the main class TestCycles according to the parameter that is defined.  
***************************************************************************
LtoSL: This package is responsible to rewrites a file of Linear TGDs to a new file called �LtoSL.txt� which contains the corresponding simple linear TGDs. 
***************************************************************************
The main method is contained in the class called LineartoSimpleLinear. In this class the user should define the input set of linear TGDs. 
After the completion of its procedure of this class a new file called LtoSL.txt is created. In this file, we have the converted Simple linear TGDs. 
Also, another class exists called Element, which contains object that are used from the class LineartoSimpleLinear.
***************************************************************************
PreProcess: In this package, there are some classes that were used in order to preprocessing some sets of TGDs that were used for experiments, in order to transform them in the right form that is acceptable by the algorithms. 


***************************************************************************
***************************************************************************

LinearTGDs
------------------------------------------

The second project called LinearTGDs contains all the material that is related to the algorithms consider linear TGDs. 
This project contains the following three packages.
***************************************************************************
Package �Detect cycles�: This package contains all the classes that implement the Donald Johnson algorithm in order to find the cycles in a directed graph. 
The main method is contained in the class called �TestCycles�. In this class the user defines if the weak acyclicity or rich acyclicity is going to be checked.
Also, in this class the file of simple linear TGDs that is going to be read must be defined. These two parameters exist at the begin of the code in this classes.  
Also, there is a class called CheckCritical which contains all the functions that have been used in order to examine whether or not a cycle is critical. 
***************************************************************************
Package �GRAPHS�: This package contains two classes called DependencyGraph and ExtendedDependencyGraph. 
These classes are responsible to compute the special edges and the normal edges of the graph that will be constructed. 
When the rich-acyclicity is checked, the �ExtendedDependencyGraph� class is used in order to construct the graph. 
On the other hand, if the weak-acyclicity is checked the system uses the �DependencyGraph� class in order to construct the graph. 
***************************************************************************
Package �PreProcess�: In this package, there are some classes that were used in order to preprocessing some datasets that were used for experiments, 
in order to convert them in the right form that is acceptable by the algorithms. 
***************************************************************************

More details about the operation of each function is presented inside the classes!!!!
