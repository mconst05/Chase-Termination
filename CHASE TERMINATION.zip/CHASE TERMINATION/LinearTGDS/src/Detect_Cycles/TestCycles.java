package Detect_Cycles;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Vector;

import GRAPHS.DependencyGraph;
import GRAPHS.ExtendedDependencyGraph;

/**
 * Testfile for simple cycle search.
 *
 * @author Marios Constantinides
 * @date 10/08/2017
 */

public class TestCycles {

	/**
	 * @param args
	 */

	public static final String INPUT_FILE_TGDS = "input_file.txt"; // input set of TGDs
	public static String acyclicity = "Rich-Acyclicity"; // define the acyclicity condition
	public static long startTime;
	public static long endTime;
	public static Map<String, String> TGDs = new HashMap<String, String>();
	public static Map<String, List<String>> SPECIAL_EDGES_EDG = new HashMap<String, List<String>>();
	public static Map<String, List<String>> SPECIAL_EDGES_DG = new HashMap<String, List<String>>();
	public static Map<String, List<String>> NORMAL_EDGES = new HashMap<String, List<String>>();
	public static List<String> ALL_NODES = new ArrayList<String>();
	public static boolean CRITICAL_CYCLE_EDG = false;
	public static boolean CRITICAL_CYCLE_DG = false;
	public static HashSet<List<String>> CHECKED_CYCLES = new HashSet<List<String>>();

	/**
	 * This function reads from a file all the TGDS and it adds them in a
	 * corresponding hashMap. The name of the file that is read is
	 * "Nodes Of Graph.txt".
	 *
	 * @param nothing
	 * @return nothing
	 * @throws FileNotFoundException
	 * 
	 */
	public static void readTGDS() throws FileNotFoundException {
		String line;
		String[] tgd;
		Scanner sc = new Scanner(new File(INPUT_FILE_TGDS));
		while (sc.hasNext()) {
			line = sc.nextLine();
			tgd = line.split("-:|:");
			TGDs.put(tgd[0], tgd[1] + "-:" + tgd[2]);
		}
		sc.close();
	}

	/**
	 * This function fills the matrix which indicates the edges of the graph. If
	 * the podition (i,j) of the matrix is labeled as True, this means that
	 * there is an edge (special or normal edge) from node i to node j. The
	 * matrix is filled based on the special and normal edges.
	 *
	 * @param matrix
	 *            Empty double array represents the matrix of the edges of the
	 *            graph
	 * @return matrix The filled matrix that indicates the edges.
	 * 
	 */
	public static boolean[][] fillMatrix(boolean[][] matrix) {
		String[] edgeElements;
		int row;
		int column;

		// considers the special edges of the graph
		if (acyclicity.equals("Rich-Acyclicity")) {
			for (String tempEdge : SPECIAL_EDGES_EDG.keySet()) {
				edgeElements = tempEdge.split("->");
				row = ALL_NODES.indexOf(edgeElements[0]);
				column = ALL_NODES.indexOf(edgeElements[1]);

				matrix[row][column] = true;
			}
		} else {
			for (String tempEdge : SPECIAL_EDGES_DG.keySet()) {
				edgeElements = tempEdge.split("->");
				row = ALL_NODES.indexOf(edgeElements[0]);
				column = ALL_NODES.indexOf(edgeElements[1]);
				matrix[row][column] = true;
			}
		}
		// considers the normal edges of the graph
		for (String tempEdge : NORMAL_EDGES.keySet()) {
			edgeElements = tempEdge.split("->");
			row = ALL_NODES.indexOf(edgeElements[0]);
			column = ALL_NODES.indexOf(edgeElements[1]);
			matrix[row][column] = true;
		}

		return matrix;
	}
	/**
	 * 
	 * Checks if the cycle cotains a special edge
	 * 
	 * @param cycle the cycle
	 * @return true if it contains, otherwise false
	 */
	public static boolean hasSpecialEdge(List cycle) {
		String first_node;
		String second_node;
		if (acyclicity.equals("Weak-Acyclicity")) {
			for (int i = 0; i < cycle.size() - 1; i++) {
				first_node = (String) cycle.get(i);
				second_node = (String) cycle.get(i + 1);
				System.out.println(first_node + second_node);
				if (SPECIAL_EDGES_DG.containsKey(first_node + "->"
						+ second_node))
					return true;
			}
		} else if (acyclicity.equals("Rich-Acyclicity")) {
			for (int i = 0; i < cycle.size() - 1; i++) {
				first_node = (String) cycle.get(i);
				second_node = (String) cycle.get(i + 1);
				System.out.println(first_node + second_node);
				if (SPECIAL_EDGES_EDG.containsKey(first_node + "->"
						+ second_node))
					System.out.println("omonia");
					return true;
			}
		}
		return false;
	}

	/**
	 * 
	 * This function takes as a parameter the cycle includes the actual noodes of the graph.
	 * Then it computes all the possible cycles of TGDs that create this cycle. Since every
	 * edge of the original cycle can be created by multiple TGD in the input file
	 * 
	 * @param cycle
	 * @return the total number of cycle of TGD that create this cycle
	 */
	public static int numberOfCycles(List cycle) {
		int count = 1;
		int numSpecialEdges = 0;
		int numNormalEdges = 0;
		int first = 0;
		int second = 0;
		if (acyclicity.equals("Weak-Acyclicity")) {
			for (int i = 0; i < cycle.size() - 1; i++) {
				numSpecialEdges = 0;
				numNormalEdges = 0;
				// take the consecutive nodes in the cycle
				first = i;
				second = i + 1;
				if (SPECIAL_EDGES_DG.containsKey(cycle.get(first) + "->"
						+ cycle.get(second))) {
					numSpecialEdges = SPECIAL_EDGES_DG.get(
							cycle.get(first) + "->" + cycle.get(second)).size();
				}
				if (NORMAL_EDGES.containsKey(cycle.get(first) + "->"
						+ cycle.get(second))) {
					numNormalEdges = NORMAL_EDGES.get(
							cycle.get(first) + "->" + cycle.get(second)).size();
				}
				count = count * (numSpecialEdges + numNormalEdges);
			}
		} else {// look for rich-acyclicity
			for (int i = 0; i < cycle.size() - 1; i++) {
				numSpecialEdges = 0;
				numNormalEdges = 0;
				// take the consecutive nodes in the cycle
				first = i;
				second = i + 1;
				if (SPECIAL_EDGES_EDG.containsKey(cycle.get(first) + "->"
						+ cycle.get(second))) {
					numSpecialEdges = SPECIAL_EDGES_EDG.get(
							cycle.get(first) + "->" + cycle.get(second)).size();
				}
				if (NORMAL_EDGES.containsKey(cycle.get(first) + "->"
						+ cycle.get(second))) {
					numNormalEdges = NORMAL_EDGES.get(
							cycle.get(first) + "->" + cycle.get(second)).size();
				}
				count = count * (numSpecialEdges + numNormalEdges);
			}
		}
		return count;
	}
	
	/**
	 * 
	 * This function checks whether the input cycle is a critical
	 * 
	 * @param cycle the cycle contains the nodes of the graph
	 * @return true if it is, otherwise false.
	 */
	public static boolean checkLCritical(List cycle) {
		int first;
		int second;
		boolean termination = false;
		// System.out.println(cycle);
		String temp;
		int numHead;
		String tgd;
		int count = 1;
		int pointer = 1; // pointer to find all combination of TGDs
		List<String> edges = new ArrayList<String>();
		List<String> cycleTGDs = new ArrayList<String>();
		int numOfCycles = numberOfCycles(cycle);

		String[][] allCycles = new String[numOfCycles][cycle.size() - 1];

		for (int i = 0; i < cycle.size() - 1; i++) {
			edges = new ArrayList<String>();
			first = i;
			second = i + 1;
			// count=1;
			// finds all tgds which contain this edge
			if (acyclicity.equals("Weak-Acyclicity")) {
				if (SPECIAL_EDGES_DG.containsKey(cycle.get(first) + "->"
						+ cycle.get(second))) {
					for (int w = 0; w < SPECIAL_EDGES_DG.get(
							cycle.get(first) + "->" + cycle.get(second)).size(); w++) {
						temp = (SPECIAL_EDGES_DG
								.get((cycle.get(first) + "->" + cycle
										.get(second))).get(w));
						// temp1=temp.split(",");
						edges.add(temp);

					}
				}
			} else {
				if (SPECIAL_EDGES_EDG.containsKey(cycle.get(first) + "->"
						+ cycle.get(second))) {
					for (int w = 0; w < SPECIAL_EDGES_EDG.get(
							cycle.get(first) + "->" + cycle.get(second)).size(); w++) {
						temp = (SPECIAL_EDGES_EDG
								.get((cycle.get(first) + "->" + cycle
										.get(second))).get(w));
						// temp1=temp.split(",");
						edges.add(temp);
					}
				}
			}
			if (NORMAL_EDGES.containsKey(cycle.get(first) + "->"
					+ cycle.get(second))) {
				for (int w = 0; w < NORMAL_EDGES.get(
						cycle.get(first) + "->" + cycle.get(second)).size(); w++) {
					temp = (NORMAL_EDGES.get((cycle.get(first) + "->" + cycle
							.get(second))).get(w));
					// temp1=temp.split(",");
					edges.add(temp);
				}
			}
			// System.out.println(edges);
			count = numOfCycles / (edges.size() * pointer);
			pointer = pointer * edges.size();

			int edge = 0;
			int c = 1;

			for (int w = 0; w < numOfCycles; w++) {
				allCycles[w][i] = edges.get(edge);
				if (c == count) {
					edge++;
					if (edge == edges.size())
						edge = 0;
					c = 0;
				}
				c++;
			}
		}

		String[] tgds;

		// boolean isActive=false;
		boolean cycleIsCritical = false;
		// put in a list the tggs of each cycle to check if it's a critical
		// cycle
		for (int w1 = 0; w1 < numOfCycles; w1++) {
			for (int w2 = 0; w2 < allCycles[w1].length; w2++) {
				tgds = allCycles[w1][w2].split(",");
				cycleTGDs.add(TGDs.get(tgds[0]) + "*" + tgds[1]);
			}

			if (acyclicity.equals("Weak-Acyclicity")) {
				if (CheckCritical.hasSpecialEdge(cycle, cycleTGDs,
						"Weak-Acyclicity")) {
					// System.out.println(cycleTGDs);
					if (!CHECKED_CYCLES.contains(cycleTGDs)) {

						cycleIsCritical = CheckCritical
								.cycleIsCritical(cycleTGDs);
						if (cycleIsCritical) {
							System.out
									.println("There is a critical cycle that contains a special edge in the Dependency Graph!!");

							System.out
									.println("As a result, the Semi-Oblivious chase will not terminate!!");
							termination = true;
						} else {
							CHECKED_CYCLES.add(cycleTGDs); // this sequence has
															// been checked
						}
					}
				}
			} else if (acyclicity.equals("Rich-Acyclicity")) {

				if (CheckCritical.hasSpecialEdge(cycle, cycleTGDs,
						"Rich-Acyclicity")) {

					if (!CHECKED_CYCLES.contains(cycleTGDs)) {

						cycleIsCritical = CheckCritical
								.cycleIsCritical(cycleTGDs);
						if (cycleIsCritical) {
							System.out
									.println("There is a critical cycle that contains a special in the Extended Dependency Graph!!");

							System.out
									.println("As a result, the Oblivious chase will not terminate!!");
							termination = true;
						} else {
							CHECKED_CYCLES.add(cycleTGDs); // this sequence has
															// been checked
						}
					}
				}
			}
			cycleTGDs = new ArrayList<String>();
			if (termination)
				break;
		}

		return termination;
	}

	public static void main(String[] args) throws IOException {
		Scanner sc = new Scanner(System.in);
		
		readTGDS();
		startTime = System.currentTimeMillis();

		if (acyclicity.equals("Rich-Acyclicity"))
			ExtendedDependencyGraph.constructEDG(INPUT_FILE_TGDS);
		else
			DependencyGraph.constructDG(INPUT_FILE_TGDS);

		String nodes[] = new String[ALL_NODES.size()];

		// create the matrix indicates the edges
		boolean adjMatrix[][] = new boolean[ALL_NODES.size()][ALL_NODES.size()];

		nodes = ALL_NODES.toArray(nodes);

		// cal function to fill the matrix
		adjMatrix = fillMatrix(adjMatrix);

		endTime = System.currentTimeMillis();
		System.out.println("Time to construct the graph: "
				+ (endTime - startTime) + " ms");

		startTime = System.currentTimeMillis();
		ElementaryCyclesSearch ecs = new ElementaryCyclesSearch(adjMatrix,
				ALL_NODES.toArray());
		List cycles = ecs.getElementaryCycles();

		// check whether there is a self-loop.
		Vector selfCycle = new Vector();
		for (int i = 0; i < ALL_NODES.size(); i++)
			for (int j = 0; j < ALL_NODES.size(); j++)
				if (i == j && adjMatrix[i][j]) {
					selfCycle.add(ALL_NODES.get(i));
					selfCycle.add(ALL_NODES.get(j));

					if (checkLCritical(selfCycle)) {
						System.out.println(selfCycle);
						endTime = System.currentTimeMillis();
						System.out
								.println("Time to check acyclicity condition: "
										+ (endTime - startTime) + " ms");
						System.exit(0);
					}
					cycles.add(selfCycle);
					selfCycle = new Vector();

				}

		if (acyclicity.equals("Weak-Acyclicity")) {
			System.out
					.println("There is no critical cycle that contains a special edge that affects the Dependency graph.");
			System.out
					.println("As a result, the Semi-Oblivious chase will terminate!!!");
		} else if (acyclicity.equals("Rich-Acyclicity")) {
			System.out
					.println("There is no critical cycle that contains a special edge that affects the Extended Dependency graph.");
			System.out
					.println("As a result, the Oblivious chase will terminate!!!");
		}
		endTime = System.currentTimeMillis();

		System.out.println("Time to check acyclicity condition: "
				+ (endTime - startTime) + " ms");
	System.out.println(cycles.size());
	}

}
