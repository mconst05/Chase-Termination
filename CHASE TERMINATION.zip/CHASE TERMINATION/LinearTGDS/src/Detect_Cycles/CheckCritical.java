package Detect_Cycles;
// implement the second condition 
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import edu.stanford.nlp.util.Pair;
/**
 * 
 * These functions are used in order to check whether a cycle is critical
 * 
 * @author Marios Constantinides
 * @date 10/08/2017
 */
public class CheckCritical {
	
	

	/**
	 * 
	 * complete the MGU
	 * 
	 * @param theta get MGU
	 * @return THE completed MGU
	 */
	public static HashMap<String,String> fixTheta(HashMap<String,String> theta){
		HashMap<String,String> temp= theta;
		for ( String var: theta.keySet()){
			while(temp.containsKey(theta.get(var))){
				theta.put(var, temp.get(theta.get(var)));
			}
		}
		return theta;
	}
	
	/**
	 * 
	 * Check whether or not the head1 unifies with body2. 
	 * 
	 * @param head1 the head of the first TGD
	 * @param body2 the body of the second TGD
	 * @param theta MGU that will be return if the above two atoms unify
	 * @return true if unify, otherwise false
	 */
	public static boolean unify(String[] head1, String[] body2,HashMap<String,String> theta){
		
		for(int i=0; i<head1.length; i++){
			if(!head1[i].equals(body2[i]))
				if(!theta.containsKey(head1[i])){
					theta.put(head1[i], body2[i]);
				}  else if (!theta.containsKey(body2[i])){
					theta.put(body2[i], head1[i]);
				}
		}
		theta=fixTheta(theta);
		
		return true;
	}
	
	

	
	/**
	 * 
	 *  Take the body of the previous resolvent and the head of the last TGD included in the sequence
	 *  Then it computes the new resolvent by using the MGU.
	 * 
	 * @param body1 body of the previous resolvent
	 * @param head2 head of the last TGD included in the sequence
	 * @param theta the MGU
	 * @return the new resolvent
	 */
	public static StringBuilder findResolvent(Pair<String,String[]> body1,Pair<String,String[]> head2,HashMap<String,String> theta){
		StringBuilder resolvent= new StringBuilder();
		String temp;
		resolvent.append(body1.first + "(");
		for(int i=0; i<body1.second.length; i++){
			 temp=body1.second[i];
			 if(theta.containsKey(temp))
				 resolvent.append(theta.get(temp));
			 //resolvent.append(unifier(temp,theta));
			 else
				 resolvent.append(temp + "2");
			 if(i!=body1.second.length-1)
				 resolvent.append(",");

		}
		resolvent.append(")-:" + head2.first + "(");
		for(int i=0; i<head2.second.length; i++){
			 temp=head2.second[i];
			 if(theta.containsKey(temp))
				 resolvent.append(theta.get(temp));
				 //resolvent.append(unifier(temp,theta));
			 else
				 resolvent.append(temp+"2");
			 if(i!=head2.second.length-1)
				 resolvent.append(",");
		}
		resolvent.append(")");
		
		return resolvent;
	}
	
	/**
	 * 
	 * Takes two TGDs and checks if they are compatible. If they are comptabile returns the 
	 * new resolvent
	 * 
	 * @param tgd1 first TGD
	 * @param tgd2 second TGD
	 * @param theta MGU
	 * @return the new resolvent
	 */
	public static StringBuilder compatible(String tgd1,String tgd2, HashMap<String,String> theta){
		boolean unify=true;
		Pair<String,String[]> head1= new Pair<String,String[]>();
		Pair<String,String[]> body1= new Pair<String,String[]>();
		Pair<String,String[]> head2= new Pair<String,String[]>();
		Pair<String,String[]> body2= new Pair<String,String[]>();
		String hd1;
		String hd2;
		String bdy1;
		String bdy2;
		String [] tgd;
		String [] atom;
		//secondCondition(tgd1,tgd2);
		
		
		tgd = tgd1.split("-:");
		bdy1 = tgd[0];
		hd1 = tgd[1];
		tgd = tgd2.split("-:");
		bdy2 = tgd[0];
		hd2 = tgd[1];
		
		atom =bdy1.split("\\(|\\,|\\)");
		body1.first=atom[0];
		body1.second= new String[atom.length-1];
		for(int i=1; i<atom.length; i++)
			body1.second[i-1]= atom[i]+"1";
		
		atom =hd1.split("\\(|\\,|\\)");
		head1.first=atom[0];
		head1.second= new String[atom.length-1];
		for(int i=1; i<atom.length; i++)
			head1.second[i-1]= atom[i]+"1";
		
		atom =hd2.split("\\(|\\,|\\)");
		head2.first=atom[0];
		head2.second= new String[atom.length-1];
		for(int i=1; i<atom.length; i++)
			head2.second[i-1]= atom[i];
		
		atom =bdy2.split("\\(|\\,|\\)");
		body2.first=atom[0];
		body2.second= new String[atom.length-1];
		for(int i=1; i<atom.length; i++)
			body2.second[i-1]= atom[i];
		
		// check whether the two atoms have the same name of predicate and the same length of variables
		if((head1.second.length!=body2.second.length)||(!head1.first.equals(body2.first)))
			unify=false;
		
		
		if(unify){
		if(secondCondition(body1,head1,body2,head2)){

		unify(head1.second,body2.second,theta);
		
		// fills the rest MGU (e.g x->x , y'->y')
		for(int i=0; i<head1.second.length; i++){
			if(!theta.containsKey(head1.second[i])){
				theta.put(head1.second[i], head1.second[i]);
				//System.out.println(theta);
			}
			if(!theta.containsKey(body2.second[i])){
				theta.put(body2.second[i], body2.second[i]);
				//System.out.println(theta);

			}
		} 		
		}else{
			//System.out.println(("Second condition of compatibility fails!!"));
			return null;
		}
		}else{
			return null;
		}
		if(unify){
			return findResolvent(body1,head2,theta);
		}
		else return null;
	}
	
	
	/**
	 * 
	 * Checks the second condition of compatibility between two TGDs
	 * 
	 * @param body1 body of the first TGD
	 * @param head1 head of the first TGD
	 * @param body2 body of the second TGD
	 * @param head2 head of the second TGD
	 * @return true if the second condition of comatibility of the two TGD is implied,
	 *         otherwise it returns false
	 */
	public static boolean secondCondition(Pair<String,String[]> body1,Pair<String,String[]> head1,Pair<String,String[]> body2,Pair<String,String[]> head2){
		HashSet<String> frontier = new HashSet<String>(); // frontier variables of tgd1
		HashSet<String> ex = new HashSet<String>(); // existential variables of tgd1
		HashMap<String,List<Integer>> posBodytgd2 = new HashMap<String,List<Integer>>();// define position of each variable in tgd2
		
		//System.out.println(Arrays.toString(body2.second));
		
		//find the pos(body(tgd2),{X}) where X belongs to var(body(tgd2))
		for(int i=0; i<body2.second.length; i++){
			//body2.second[i-1]= atom[i];
			if (posBodytgd2.containsKey(body2.second[i]))
				//add the tgd rule in which comes from
				posBodytgd2.get(body2.second[i]).add(i);
			else {
				//if does not exist, add it and initialize the list with the rules from which comes from
				posBodytgd2.put(body2.second[i], new ArrayList<Integer>());
				posBodytgd2.get(body2.second[i]).add(i);
			}
		}
		
		//find frontier and existential sets
		for(int i=0; i<head1.second.length; i++)
			if(Arrays.asList(body1.second).contains(head1.second[i]))
				frontier.add(head1.second[i]);
			else
				ex.add(head1.second[i]); 
		
		boolean cnd1; //var(head(s1),P) subset of frontier
		boolean cnd2; //var(head(s1),P) subset of ex
		boolean result=true;
		int c;
		String Z="";
		for(String var: posBodytgd2.keySet()){
			//System.out.println("var: " + var);
			cnd1=true;
			cnd2=true;
			c=1;
			for(int i=0; i<posBodytgd2.get(var).size(); i++){
				//var(head(s1),P) subset of frontier
				if(!frontier.contains(head1.second[posBodytgd2.get(var).get(i)]))
					cnd1=false;
				
				//var(head(s1),P) subset of ex
				if(!ex.contains(head1.second[posBodytgd2.get(var).get(i)])){
					cnd2=false;
				}else{
					// check if it's the same existential variable
					if(c==1){
					Z=head1.second[posBodytgd2.get(var).get(i)];
					c++;
					}else{
						// if it's a different existential variable from before condition 2 is false
						if (!Z.equals(head1.second[posBodytgd2.get(var).get(i)]))
						 cnd2=false;
						 
						
					}
				}
			}
			result=cnd1||cnd2;
			
			if(result==false)
				break;
		}
		return result;
	}
	
	/**
	 * 
	 * checks whether acycle is critical
	 * 
	 * @param cycle the cycle
	 * @return true if it is, otherwise it returns false
	 */
	public static boolean cycleIsCritical(List<String> cycle){
		int numHead;
		String[] headElements;
		String body;
		String[] tgd;
		String[] edge;
		
		List<String> cl= new ArrayList<String>();
		//System.out.println(cycle.get(0));
		
		String tgd1[]= cycle.get(0).split("-:");
		int k= tgd1[0].split("\\(|\\,|\\)").length;
		
		HashMap<String,String> theta;
		StringBuilder resolvent;
		StringBuilder temp;
		for(int i=0; i<k; i++){
			for(int j=0; j<cycle.size(); j++){
				edge =cycle.get(j).split("\\*");
				numHead = Integer.parseInt(edge[1]);
				tgd=edge[0].split("-:");
				body=tgd[0];
				headElements=tgd[1].split("\\.");
				cl.add(body + "-:" + headElements[numHead-1]);
			}
	}
		
		resolvent= new StringBuilder(cl.get(0));
		int second; 
		for(int i=0; i<cl.size()-1; i++){
			theta= new HashMap<String,String>();
			
			second=i+1;
			temp=compatible(resolvent.toString(),cl.get(second),theta);
			if(temp!=null){
				resolvent= temp;
				//System.out.println(theta);
			}else
				return false;
			//System.out.println(resolvent);
			//second++;
		}
		return true;
	}
	
	
	/**
	 * 
	 * check if the cycle contains a special edge
	 * 
	 * @param cycle a cycle of the nodes of the graph
	 * @param cycleTGDS the cycle indldes TGDs that makes the actual cycle
	 * @param acyclicity takes "Weak-acyclicity" or "Rich-Acyclicity" in order to check
	 * the corresponding hashMaps
	 * @return  true if the cycle contains a special edge, otherwise it returns false
	 */
	public static boolean hasSpecialEdge(List<String> cycle, List<String> cycleTGDS,String acyclicity){
		List<String> positions=new ArrayList<String>();
		
		String[] edge;
		String[] body;
		String[] head;
		int positionBody;
		int positionHead;
		int start;
		int end;
		String[] temp;
		String tgd;
		int numHead;
		
		for(int i=0; i<cycle.size(); i++){
			
			start=(cycle.get(i).indexOf("["));
			end=(cycle.get(i).indexOf("]"));
			positions.add(cycle.get(i).substring((start+1), (end)));
		}
		
		for(int i=0; i<cycleTGDS.size(); i++){
			
			temp=cycleTGDS.get(i).split("\\*");
			tgd=temp[0];
			numHead=Integer.parseInt(temp[1]);
			/*System.out.println("tgd" + tgd);
			System.out.println(numHead);*/
			edge=tgd.split("-:");
			body=edge[0].split("\\(|\\,|\\)");
			
			temp=edge[1].split("\\.");
			//System.out.println(Arrays.toString(temp));
			head=temp[numHead-1].split("\\(|\\,|\\)");
			//System.out.println(Arrays.toString(body));
			positionBody=Integer.parseInt(positions.get(i));
			positionHead=Integer.parseInt(positions.get(i+1));
			/*System.out.println(positionBody);
			System.out.println(positionHead);*/
			//System.out.println();
			if(!body[(positionBody)].equals(head[(positionHead)])){
				if((acyclicity.equals("Rich-Acyclicity"))&&TestCycles.SPECIAL_EDGES_EDG.containsKey((cycle.get(i)+"->"+cycle.get(i+1)))){
					return true;
				}
				if((acyclicity.equals("Weak-Acyclicity"))&&TestCycles.SPECIAL_EDGES_DG.containsKey(cycle.get(i)+"->"+cycle.get(i+1)))
					return true;	
			}
			
		}
		return false;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HashMap<String,String> theta = new HashMap<String,String>();
		//tgds for testing
		/*String tgd1= "p(X,Y)-:s(X,Y,Z)";
		String tgd2= "s(X,X,Y)-:p(X,Z)";
		String tgd3= "p(X,Y)-:p(X,Z)";*/
		
		
		/*System.out.println(compatible("p(X,Y,X)-:s(X,Y,X)","s(Y,Z,X)-:p(Y,X,X)",theta));
		System.out.println(theta);
		*/
		/***************TEST1**************/
		/* CYCLE IS ACTIVE*/
		/*List<String> cycle= new ArrayList<String>();
		for(int i=0; i<2; i++){
		cycle.add(tgd1);
		cycle.add(tgd2);
		}
		System.out.println(CycleIsActive(cycle));*/

		/***************TEST2**************/
		// RETURN CORRECT RESOLVENT
		//StringBuilder resolvent= compatible(tgd1,tgd2,theta);
		//System.out.println(resolvent);
		//System.out.println(theta);
		/*int count=6;
		List<String> cycle= new ArrayList<String>();
		for(int i=0; i<count; i++){
		cycle.add(tgd1);
		cycle.add(tgd2);
		}
		int first;
		int second;
		System.out.println("*****TEST******");
		StringBuilder resolvent=new StringBuilder(tgd1);
			first=0;
			second=1;
			
			theta = new HashMap<String,String>();
			resolvent=compatible(cycle.get(first),cycle.get(second),theta);
			System.out.println("(12)1ooo resolvent: " + resolvent);
			System.out.println("theta=> " + theta);
			
			theta = new HashMap<String,String>();
			System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!");
			second=2;
			resolvent=compatible(resolvent.toString(),cycle.get(second),theta);
			System.out.println("(121) 2ooo resolvent: " + resolvent);
			System.out.println("theta=> " + theta);

			
			theta = new HashMap<String,String>();
			System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!");
			second=3;
			resolvent=compatible(resolvent.toString(),cycle.get(second),theta);
			System.out.println("(1212) 3ooo resolvent" + resolvent );
			System.out.println("theta=> " + theta);

			theta = new HashMap<String,String>();
			System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!");
			second=4;
			resolvent=compatible(resolvent.toString(),cycle.get(second),theta);
			System.out.println("(12121) 4ooo resolvent" + resolvent );
			System.out.println("theta=> " + theta);

			theta = new HashMap<String,String>();
			System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!");
			second=5;
			resolvent=compatible(resolvent.toString(),cycle.get(second),theta);
			System.out.println("(121212) 5ooo resolvent" + resolvent );
			System.out.println("theta=> " + theta);*/
		
		/*
		*//************TEST3************//*
		List<String> cycle= new ArrayList<String>();
		cycle.add(tgd1);
		cycle.add(tgd2);
		//System.out.println(cycle);
		System.out.println(CycleAlwaysActive(cycle));
		//System.out.println(cycle);
*/	
		//*********TEST hasSpecialEdge********//*
		List<String> cycle= new ArrayList<String>();
		cycle.add("p[2]");
		cycle.add("s[2]");
		cycle.add("p[2]");
		List<String> cycle1= new ArrayList<String>();
		cycle1.add("p(X,Y,Z)-:s(X,Y,Z)\\*1");
		cycle1.add("s(X,Y,X)-:p(Y,Z,X)\\*1");
		System.out.println(hasSpecialEdge(cycle,cycle1,"Weak-Acyclicity"));
/*
		HashMap<String,String> pp= new HashMap<String,String>();
		pp.put("A", "a");
		pp.put("B", "b");
		pp.put("c", "c");
		//System.out.println(mapSameValue("c",pp));
		
		HashMap<String,String> p= new HashMap<String,String>();
		p.put("O", "A");
		p.put("B", "C");
		p.put("A", "W0" );
		p.put("AW", "O");
		pp=fixTheta(p);
		//System.out.println(mapSameValue("c",pp));
		
		//p=pp;
		System.out.println(pp);*/
		
		/******TEST4*********/
		/*String tgd12= "s(X,Z,Y)-:p(X,Z,Y)";
		String tgd13= "p(X,X,Y)-:t(X,Y,T)";
		String tgd14= "t(X,Z,T)-:p(X,X,Y)";
		List<String> cc= new ArrayList<String>();
		cc.add(tgd12);
		cc.add(tgd13);
		cc.add(tgd14);
		cycleIsActive(cc);*/
	}

}
