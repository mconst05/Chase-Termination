package PreProcess;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;


public class Blank {
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		//read the files with the TGDs
				Scanner sc = new Scanner(new File("00013L.txt"));
				File file = new File("BlankDelete.txt"); 
				file.createNewFile();
				FileWriter writer = new FileWriter(file);
				//int c=1;
				String line;
				String line1;
				// read each TGD one-by-one
				while (sc.hasNext()){
					line= sc.nextLine();
					//System.out.println(line);
					if(!line.equals("") && !line.contains("%"))
					{
						line1 = line;
						//System.out.println(line1);
						writer.write(line1);
						writer.write("\n");
						
					}
					/*if(sc.hasNext())
					{
						writer.write("\n");
							
					}*/
					//c++;
					//line1 = "";
						
				}
					
				writer.close();
				System.out.println("Blank lines have been removed");
				
	}
}
