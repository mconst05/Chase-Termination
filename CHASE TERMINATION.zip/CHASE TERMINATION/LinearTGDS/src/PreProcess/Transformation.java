package PreProcess;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Transformation {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		//read the files with the TGDs
				Scanner sc = new Scanner(new File("BlankDelete.txt"));
				File file = new File("SHUANG.txt"); 
				file.createNewFile();
				FileWriter writer = new FileWriter(file);
				int c=1;
				String[] tgd;
				String[] tgd1;
				String line;
				String[] body1;
				String Body = null;
				String[] head = null;
				String[] head1;
				String Head = "";
				// read each TGD one-by-one
				while (sc.hasNext()){
					line= sc.nextLine();
					tgd1=line.split(" :- ");
					//System.out.println(tgd1[1]);
					body1 = tgd1[1].split(", ");
					
					if(body1.length>1)
					{
						line = "W";
					}
					if(!line.equals("W"))
					{
						tgd = line.split(" :- ");
						head = tgd[0].split("\\),");
						//System.out.println(line);
						if(head[0].contains("!"))
						{
							head1 = head[0].split(" ");
							head[0]=head1[1]+")";
						}
						//System.out.println(head[0]);
						
						for(int j=0; j<head.length; j++)
						{
							Head = Head + head[j] + ".";
							Head = Head.replace(":", "A");
						}
						Body = tgd[1].replace(":", "A");
						//System.out.println(Head);
						
						//System.out.println(Body);
						writer.write("r" + c + ":");
						writer.write(Body + "-:");
						writer.write(Head.substring(0, Head.length()-1));
						if(sc.hasNext())
						{
							writer.write("\n");
							
						}
						c++;
						
					}
					//System.out.println(head[0]);
					
					Body = "";
					Head = "";
					
					
				}
				writer.close();
				System.out.println("The file is transformed !!");
				
				
	}

}
