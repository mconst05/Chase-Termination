package GRAPHS;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;

import Detect_Cycles.TestCycles;
import edu.stanford.nlp.util.Pair;
/**
 * 
 * This class is responsible to fill the HashMaps of normal edges, special edges and nodes
 * in order to construct the dependency graph based on a file of simple linear TGDs.
 * 
 * @author Marios Constantinides
 * @date 10/08/2017
 */
public class DependencyGraph {

	/**
	 * This function takes as an input the body and the head of each TGD. Then
	 * it produces the special edges that are came out from this TGD. The
	 * special edges are generated according to the rules that are based on the
	 * dependency graph. Finally, the produced special edges are added in the
	 * corresponding HashMap of special edges.
	 *
	 * @param nameTGD the name of the TGD
	 * @param body
	 *            A pair. The first field of the pair contains the name of the
	 *            body atom and the second field is a list containing the
	 *            variables of the atom in the body
	 * @param head
	 *            List of pairs. Each pair in a list corresponds to an atom
	 *            included in the head of the TGD. The first field of the pair
	 *            defines the name of the body atom and the second field is a
	 *            list containing the variables of the specific atom.
	 * @return nothing
	 * 
	 */

	    public static void findSpecialEdges(String nameTGD,Pair<String, ArrayList<String>> body, List<Pair<String, ArrayList<String>>> head){
			Pair<String, ArrayList<String>> tempHead = new Pair<String, ArrayList<String>>();
			String specialEdge;
			for(int i=0; i<head.size(); i++){
				tempHead= head.get(i); // get each predicate of the head
				for( int j=0; j<tempHead.second.size(); j++)
				 if(!body.second.contains(tempHead.second.get(j))){
					 for(int w=0; w<body.second.size(); w++){
						 // check whether the current string is front
						 if(tempHead.second.contains(body.second.get(w))){	 
						 specialEdge=(body.first + "[" + (w+1) + "]" + "->" + tempHead.first + "[" + (j+1) + "]");
						 if (TestCycles.SPECIAL_EDGES_DG.containsKey(specialEdge))
								//add the tgd rule in which comes from
							 TestCycles.SPECIAL_EDGES_DG.get(specialEdge).add(nameTGD+ "," + (i+1));
							else {
								//if does not exist, add it and initialize the list with the rules from which comes from
								TestCycles.SPECIAL_EDGES_DG.put(specialEdge, new ArrayList<String>());
								TestCycles.SPECIAL_EDGES_DG.get(specialEdge).add(nameTGD + "," + (i+1));
							}
							 
						 }
					 }
				 }
			}
		}

	    /**
		 * This function takes as an input the body and the head of each TGD. Then
		 * it produces the normal edges that are came out from this TGD. The
		 * normal edges are generated according to the rules that are based on the
		 * dependency graph. Finally, the produced special edges are added in the
		 * corresponding HashMap of normal edges.
		 *
		 * @param body
		 *            A pair. The first field of the pair contains the name of the
		 *            body atom and the second field is a list containing the
		 *            variables of the atom in the body
		 * @param head
		 *            List of pairs. Each pair in a list corresponds to an atom
		 *            included in the head of the TGD. The first field of the pair
		 *            defines the name of the body atom and the second field is a
		 *            list containing the variables of the specific atom.
		 * @return nothing
		 * 
		 */
	public static void findNormalEdges(String nameTGD, Pair<String, ArrayList<String>> body,
			List<Pair<String, ArrayList<String>>> head) {
		Pair<String, ArrayList<String>> tempHead = new Pair<String, ArrayList<String>>();
		String normalEdge;
		// System.out.println("Normal Edges of the graph");
		for (int i = 0; i < head.size(); i++) {
			tempHead = head.get(i);
			for (int j = 0; j < tempHead.second.size(); j++)
				if (body.second.contains(tempHead.second.get(j))) {
					for (int w = 0; w < body.second.size(); w++) {
						if (body.second.get(w)
								.compareTo(tempHead.second.get(j)) == 0) {
							normalEdge = (body.first + "[" + (w + 1) + "]"
									+ "->" + tempHead.first + "[" + (j + 1) + "]");
							if (TestCycles.NORMAL_EDGES.containsKey(normalEdge))
								TestCycles.NORMAL_EDGES.get(normalEdge).add(nameTGD+ "," + (i+1));
							else {
								TestCycles.NORMAL_EDGES.put(normalEdge, new ArrayList<String>());
								TestCycles.NORMAL_EDGES.get(normalEdge).add(nameTGD+ "," + (i+1));
							}
						}
					}
				}
		}
	}

	
	 /**
	 * This function takes as an input the file with the TGDs. Then it processes each TGD
	 * contained in the input file in order to find the normal edges, special edges and
	 * the nodes of the dependency graph.
	 *
	 * @param file
	 *            The input file that contains the simple linear TGDs.
	 * @return nothing
	 * 
	 */
	public static void constructDG(String file) throws IOException{
		Pair<String, ArrayList<String>> body; 
		
		List<Pair<String, ArrayList<String>>> head;
		//Pair<String, ArrayList<String>> head = new Pair<String, ArrayList<String>>();
		//head.second= new ArrayList<String>();
		
		String line; // string to read each linein the file
		String nameTGD; // name of TGD
		String bodyTemp; // body of TGD
		String[] bodyElements; // temporary table of body elements
		String[] headElements; // temporary table of head elements
		String headTemp; // head of TGD
		String[] headPredicates; // predicates of the head
		
		
		
		//read the files with the TGDs
		Scanner sc = new Scanner(new File(file));
		// read each TGD one-by-one
		while (sc.hasNext()){
			
			body = new Pair<String, ArrayList<String>>();
			body.second= new ArrayList<String>();
			head = new ArrayList<Pair<String, ArrayList<String>>>();

			line=sc.nextLine();
			String[] table = line.split("-:|:");
			
			nameTGD=table[0];
			bodyTemp=table[1];
			headTemp=table[2];
			
			bodyElements = bodyTemp.split("\\(|\\,|\\)");

			body.first=bodyElements[0];

			for (int i=1; i<bodyElements.length; i++)
				body.second.add(bodyElements[i]);
			
			for (int i =0; i<body.second.size(); i++){
				if(!TestCycles.ALL_NODES.contains(body.first.toString() + "[" + (i+ 1) + "]" ))
					TestCycles.ALL_NODES.add(body.first.toString() + "[" + (i+ 1) + "]" );
			}
			
			//manage the head of the TGD
			headPredicates = headTemp.split("\\.");

			for (int i=0; i<headPredicates.length; i++){
			Pair<String, ArrayList<String>> tempHead = new Pair<String, ArrayList<String>>();
			tempHead.second= new ArrayList<String>();
			
			
			headElements = headPredicates[i].split("\\(|\\,|\\)");

			tempHead.first=headElements[0];
			
			for (int j=1; j<headElements.length; j++)
				tempHead.second.add(headElements[j]);
						
			for (int j=0; j<tempHead.second.size(); j++){
				if(!TestCycles.ALL_NODES.contains(tempHead.first.toString() + "[" + (j+1 ) + "]" ))
				TestCycles.ALL_NODES.add(tempHead.first.toString() + "[" + (j+1 ) + "]" );
			}
			
			head.add(tempHead);
			}
            // call a function to produce the special edges 
			findSpecialEdges(nameTGD,body,head);
			// call a function to produce the normal edges
			findNormalEdges(nameTGD,body,head);
		}
		sc.close();

		// print information of the dependency graph
		System.out.println("Number of nodes of the graph: " + TestCycles.ALL_NODES.size());
		System.out.println("Number of special edges of the graph: " + TestCycles.SPECIAL_EDGES_DG.size());
		System.out.println("Number of normal edges of the graph: " + TestCycles.NORMAL_EDGES.size());
		
	}



}
