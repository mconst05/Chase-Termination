package Detect_Cycles;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Vector;


import GRAPHS.DependencyGraph;
import GRAPHS.ExtendedDependencyGraph;

/**
 * Testfile for simple cycle search.
 * 
 * @author Marios Constantinides
 * @date 10/08/2017
 */

public class TestCycles {

	/**
	 * @param args
	 */
	
	public static final String INPUT_FILE_TGDS="input_file.txt"; // input set of TGDs
	public static final String acyclicity="Weak-Acyclicity"; // define acyclicity condition
	public static long startTime;
	public static long endTime;
	public static Map<String, List<String>> SPECIAL_EDGES_EDG = new HashMap<String, List<String>>();
	public static Map<String, List<String>> SPECIAL_EDGES_DG = new HashMap<String, List<String>>();
	public static Map<String, List<String>> NORMAL_EDGES = new HashMap<String, List<String>>();
	public static List<String> ALL_NODES = new ArrayList<String>();
	
	/**
	 * This function takes as an input a cycle (list). Two successive elements
	 * of the list i and j represent an edge from i to j. This
	 * edge is included in the cycle. The function get every two successive
	 * elements of the list and check whether or not the constructed edge 
	 * is a special edge. if it is, the function returns true (cycle
	 * contains a special edge), otherwise, it returns false (cycle does not
	 * contain a special edge).
	 *
	 * @param cycle
	 *            list that contains the nodes that are included in the cycle
	 * @return true if there exist a special edge in the cycle false if there
	 *         not exist a special edge in the cycle
	 * 
	 */
	public static boolean checkAcyclicity(List cycle) {
		boolean termination = false;
		String first_node;
		String second_node;
		String specialEdge;
		
		if (acyclicity.equals("Rich-Acyclicity")) {
			for (int i = 0; i < (cycle.size() - 1); i++) {
				first_node = (String) cycle.get(i);
				second_node = (String) cycle.get(i + 1);
				if (SPECIAL_EDGES_EDG.containsKey(first_node + "->" + second_node)) {
					System.out.println("There is a cycle that contains a special edge in the Extended Dependency Graph!!");
					System.out.println("As a result, the Oblivious chase will not terminate!!");
					termination = true;
					break; // we find a special edge break
				}
			}
		} else if (acyclicity.equals("Weak-Acyclicity")) {
			for (int i = 0; i < (cycle.size() - 1); i++) {
				first_node = (String) cycle.get(i);
				second_node = (String) cycle.get(i + 1);
				if (SPECIAL_EDGES_DG.containsKey(first_node + "->" + second_node)) {
					System.out.println("There is a cycle that contains a special edge in the Dependency Graph!!");
					System.out.println("As a result, the Semi-Oblivious chase will not terminate!!");
					termination = true;
					break; // we found a special edge
				}
			}
		}
		return termination;
	}
    
	/**
	 * This function fills the matrix which indicates the edges of the graph. If
	 * the podition (i,j) of the matrix is labeled as True, this means that
	 * there is an edge (special or normal edge) from node i to node j. The
	 * matrix is filled based on the special and normal edges.
	 *
	 * @param matrix
	 *            Empty double array represents the matrix of the edges of the
	 *            graph
	 * @return matrix The filled matrix that indicates the edges.
	 * 
	 */
	public static boolean[][] fillMatrix(boolean[][] matrix) {
		String[] edgeElements;
		int row;
		int column;

		// considers the special edges of the graph
		if (acyclicity.equals("Rich-Acyclicity")) {
			for (String tempEdge : SPECIAL_EDGES_EDG.keySet()) {
				edgeElements = tempEdge.split("->");
				row = ALL_NODES.indexOf(edgeElements[0]);
				column = ALL_NODES.indexOf(edgeElements[1]);
				matrix[row][column] = true;
			}
		} else {
			for (String tempEdge : SPECIAL_EDGES_DG.keySet()) {
				edgeElements = tempEdge.split("->");
				row = ALL_NODES.indexOf(edgeElements[0]);
				column = ALL_NODES.indexOf(edgeElements[1]);
				matrix[row][column] = true;
			}
		}

		// considers the normal edges of the graph
		for (String tempEdge : NORMAL_EDGES.keySet()) {
			edgeElements = tempEdge.split("->");
			row = ALL_NODES.indexOf(edgeElements[0]);
			column = ALL_NODES.indexOf(edgeElements[1]);
			//System.out.println(column);
			matrix[row][column] = true;
		}

		return matrix;
	}
	
	public static void main(String[] args) throws IOException {
		startTime = System.currentTimeMillis();

		if(acyclicity.equals("Rich-Acyclicity"))
			ExtendedDependencyGraph.constructEDG(INPUT_FILE_TGDS);
		else
			DependencyGraph.constructDG(INPUT_FILE_TGDS);
		
		
		String nodes[] = new String[ALL_NODES.size()];
		
		// create the matrix indicates the edges
		boolean adjMatrix[][] = new boolean[ALL_NODES.size()][ALL_NODES.size()];

		nodes = ALL_NODES.toArray(nodes);

		// cal function to fill the matrix
		adjMatrix = fillMatrix(adjMatrix);
		
		endTime = System.currentTimeMillis();
		System.out.println("Time to connstruct the graph: " + (endTime - startTime) +" ms");
		
		startTime= System.currentTimeMillis();
		
		ElementaryCyclesSearch ecs = new ElementaryCyclesSearch(adjMatrix,
				ALL_NODES.toArray());
		
		List cycles = ecs.getElementaryCycles();
		// check whether there is a self-loop.
		Vector selfCycle = new Vector();
		for (int i = 0; i < ALL_NODES.size(); i++)
			for (int j = 0; j < ALL_NODES.size(); j++)
				if (i == j && adjMatrix[i][j]) {
					selfCycle.add(ALL_NODES.get(i));
					selfCycle.add(ALL_NODES.get(j));
					
					if (checkAcyclicity(selfCycle)) {
						endTime   = System.currentTimeMillis();
						System.out.println("Time to check acyclicity condition: " + (endTime - startTime) +" ms");
						System.exit(0);
					}
					cycles.add(selfCycle);
					selfCycle = new Vector();

				}

		if (acyclicity.equals("Weak-Acyclicity")) {
			System.out.println("There is no cycle that contains a special edge that affects the Dependency graph.");
			System.out.println("As a result, the Semi-Oblivious chase will terminate!!!");
		} else if (acyclicity.equals("Rich-Acyclicity")) {
			System.out.println("There is no cycle that contains a special edge that affects the Extended Dependency graph.");
			System.out.println("As a result, the Oblivious chase will terminate!!!");
		}
		endTime   = System.currentTimeMillis();
		System.out.println("Time to check acyclicity condition: " + (endTime - startTime) +" ms");
		
	}

}
