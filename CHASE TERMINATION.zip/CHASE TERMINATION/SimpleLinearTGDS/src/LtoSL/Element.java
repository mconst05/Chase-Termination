package LtoSL;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * 
 * @author Marios Constantinides
 *
 */
public class Element{
	
	public String name;
	public int value;
	
	
	public Element(String name,int value){
		this.name=name;
		this.value=value;
	}
	
}
