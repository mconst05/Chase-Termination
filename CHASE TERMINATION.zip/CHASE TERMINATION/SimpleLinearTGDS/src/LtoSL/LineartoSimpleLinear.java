package LtoSL;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;

/**
 * This class is responsible to transform a file of linear TGDs into a file of 
 * simple linear TGDs.
 * 
 * @author Marios Constantinides
 *
 */
public class LineartoSimpleLinear {
	public static List<String> TGDS = new ArrayList<String>();
	public static final String file = "SHUANG.txt";
	public static int numTGD=1;
	
	
	
	public static void fixMapping(HashMap<String,Integer> mapping){
		HashSet<Integer> nums = new HashSet<Integer>();
		for (String var : mapping.keySet()){
			nums.add(mapping.get(var));
		}
	}
	
	/**
	 * 
	 * write the TGD to the output file 
	 * 
	 * @param nameTGD name of the TGD
	 * @param body body of the TGD
	 * @param headElements elements of th head of the TGD
	 * @param mapping contains the name of the variable as key, and integer id as a value
	 * @param elements contains the variables of the body of the TGD
	 */
	public static void printTGD(String nameTGD,String[] body, List<String> headElements,HashMap<String, Integer> mapping, List<String> elements) {
		List<String> temp;
		HashSet<Integer> nums = new HashSet<Integer>();
		StringBuilder tgd = new StringBuilder();
		String[] head;	
		
		tgd.append("r" + numTGD + ":");
		numTGD++;
		tgd.append(body[0]);
		for(int i=1; i<body.length; i++){
		tgd.append(mapping.get(body[i]));
		nums.add(mapping.get(body[i]));
		if(i!=body.length-1)
			tgd.append("*");
		else
			tgd.append("(");
		}
		for(int i: nums){
			String element=elements.get(i-1);
			tgd.append(element);
			tgd.append(",");
		}
		tgd.setLength(tgd.length()-1);
		tgd.append(")");
		int flag=0;
		for(int w=0; w<headElements.size(); w++){
		temp = new ArrayList<String>();
		head=headElements.get(w).split("\\(|\\,|\\)");
		if(flag==0){
			tgd.append("-:" + head[0]);
			flag++;
		}
		else
			tgd.append("." + head[0]);

		int c=1;
		 HashMap<String,Integer> tt= new HashMap<String,Integer>();
		for(int i=1; i<head.length; i++){
			if(mapping.containsKey(head[i])){
				if(!temp.contains(elements.get(mapping.get(head[i])-1))){
					temp.add(elements.get(mapping.get(head[i])-1));
					if(!tt.containsKey(elements.get(mapping.get(head[i])-1))){
					tt.put(elements.get(mapping.get(head[i])-1), c);
					c++;
					}
				}else{
					temp.add(elements.get(mapping.get(head[i])-1));
				}
			}else{
				if(!temp.contains(head[i])){
					temp.add(head[i]);
					if(!tt.containsKey(head[i])){
						tt.put(head[i], c);
						c++;
					}
				}else{
					temp.add(head[i]);
				}
		}
		}
		
		HashSet<String> hd = new HashSet<String>();
		for(int i=0; i<temp.size(); i++){
			tgd.append(tt.get(temp.get(i))+ "*");
		}
		tgd.setLength(tgd.length()-1);
		tgd.append("(");
		for(int i=0; i<temp.size(); i++){
			if(!hd.contains(temp.get(i))){
			tgd.append(temp.get(i) + ",");
			hd.add(temp.get(i));
			}
			}
		tgd.setLength(tgd.length()-1);
		tgd.append(")");
	
	}
		TGDS.add(tgd.toString());
	}
	

	public static int findMin(List<String> list,HashMap<String, Integer> mapping) {
		int min = Integer.MAX_VALUE;
		String temp;
		int num;
		for (int i = 0; i < list.size(); i++) {
			temp = list.get(i);
			num = mapping.get(temp);
			if (num < min)
				min = num;
		}
		return min;
	}
	/**
	 * 
	 * Find all the partitions of the input set
	 * 
	 * @param inputSet the set that is going to be partitioned
	 * @return
	 */
	public static List<List<List<String>>> partitions(List<String> inputSet) {
		List<List<List<String>>> res = new ArrayList<>();
		if (inputSet.isEmpty()) {
			List<List<String>> empty = new ArrayList<>();
			res.add(empty);
			return res;
		}
		
		int limit = 1 << (inputSet.size() - 1);
		for (int j = 0; j < limit; ++j) {
			List<List<String>> parts = new ArrayList<>();
			List<String> part1 = new ArrayList<>();
			List<String> part2 = new ArrayList<>();
			parts.add(part1);
			parts.add(part2);
			int i = j;
			for (String item : inputSet) {
				parts.get(i & 1).add(item);
				i >>= 1;
			}
			for (List<List<String>> b : partitions(part2)) {
				List<List<String>> holder = new ArrayList<>();
				holder.add(part1);

				holder.addAll(b);
				res.add(holder);

			}
		}

		return res;
	}

	public static void LtoSL(String tgd) {
		
		String[] table = tgd.split("-:|:");
		
		String[] body; // temporary table of body elements
		String[] head; // temporary table of head elements
		String nameTGD;
		ArrayList<String> bodyElements = new ArrayList<String>();
		List<String> headElements = new ArrayList<String>();
		ArrayList<String> list = new ArrayList<String>();
		HashMap<String, Integer> mapper = new HashMap<String, Integer>();
		HashMap<String, Integer> reducer = new HashMap<String,Integer>();
		List<Element> replace = new ArrayList<Element>();
		Element temp;
		String[] hd = table[2].split("\\.");
		headElements=Arrays.asList(hd);
		int counter = 1;
		
		nameTGD=table[0];
		body = table[1].split("\\(|\\,|\\)");
		head = table[2].split("\\(|\\,|\\)");

		for (int i = 1; i < body.length; i++) {
			bodyElements.add(body[i]);
			if (!mapper.containsKey(body[i])) {
				mapper.put(body[i], counter);
				list.add(body[i]);
				counter++;
			}
		}
		
		int min = findMin(list, mapper);
	
		
		List<List<List<String>>> partitions = partitions(list);
		List<List<String>> partition = new ArrayList<>();
		List<String> subset = new ArrayList<>();

		for (int i = 0; i < partitions.size(); i++) {
			partition = partitions.get(i);

			for (int j = 0; j < partition.size(); j++) {
				subset = partition.get(j);
				min = findMin(subset, mapper);
				for (int w = 0; w < subset.size(); w++) {
					temp = new Element(subset.get(w), min);
					replace.add(temp);
				}
			}
			//sort the list according to values of letters
			Collections.sort(replace, new Comparator<Element>(){
						@Override
						public int compare(Element e1, Element e2) {
							// TODO Auto-generated method stub
							if(e1.value > e2.value)
								return 1;
							else if(e1.value == e2.value)
								return 0;
							else
								return -1;
						}
					});
			
			int c=1;
			int j=0;
			while(j<replace.size()){
				if(c==replace.get(j).value){
					j++;
				}else{
					c++;
					if(c!=replace.get(j).value)
						replace.get(j).value=c;
				}
			}
			
			reducer=new HashMap<String,Integer>();
			for(int q=0; q<replace.size(); q++){
				reducer.put(replace.get(q).name, replace.get(q).value);
			}
			
			
			printTGD(nameTGD,body, headElements, reducer, list);
			replace = new ArrayList<Element>();
		}

		
	}
	
	public static void createFile() throws IOException{
		File file = new File("LtoSL.txt"); 
		file.createNewFile();
		FileWriter writer = new FileWriter(file);
		int counter=0;
		for(String tgd : TGDS){
			writer.write(tgd);
			counter++;
			if(counter!=TGDS.size())
				writer.write("\n");
		
		}
		writer.close();
	}
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		//read the files with the TGDs
		Scanner sc = new Scanner(new File(file));
		// read each TGD one-by-one
		while (sc.hasNext()){
			LtoSL(sc.nextLine());
		}
		createFile();
		System.out.println("The covertion of Linear TGDs to Simple Linear has completed!!");
		/********TEST1*******/
		//String tgd = "r1:p(X,Y,X,W)-:t(Y,U,W)";
		//LtoSL(tgd);
		/******** TEST2 *******/
		/*
		 * HashMap<String,Integer> mm= new HashMap<String,Integer>();
		 * mm.put("A", 2); mm.put("omonoia", 5); mm.put("CA", 5); List<String>
		 * list= new ArrayList<String>(); list.add("A"); list.add("omonoia");
		 * list.add("CA"); System.out.println(findMin(list,mm));
		 */
	}
	
}
